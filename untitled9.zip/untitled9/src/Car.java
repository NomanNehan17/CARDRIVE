import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.*;
import javax.sound.sampled.Clip;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;
                                                                   //C211017
public class Car {
    Image carImage;
    Image carStopImage;
    Image carRunningRight;
    ImageIcon carImageIcon;
    //Clip player = null;
    int x;
    int y;
    AudioInputStream carRunningSound;
    Clip player;
    Car ()
    {
        carImageIcon = new ImageIcon( "car.png");
        carStopImage = carImageIcon.getImage();

        carImageIcon = new ImageIcon( "still.gif");
        carRunningRight = carImageIcon.getImage();

        carImage = carStopImage;
        x= 120;
        y= 450;

    }
    void move (KeyEvent e) throws Exception {
        if (e.getKeyCode() == 39)
            x = x + 5;
        if (e.getKeyCode() == 37)
            x = x - 5;

        if (e.getKeyCode() == 40)
            y = y + 5;
        if (e.getKeyCode() == 38)
            y = y - 5;

        carImage = carRunningRight;
     ////Sound Add
        carRunningSound = AudioSystem.getAudioInputStream(new File("car_drive_sound.wav").getAbsoluteFile());
        player = AudioSystem.getClip();
        //Clip player = AudioSystem.getClip();
        player.open(carRunningSound);
        player.start();
    }

        void stop ()
        {
        carImage = carStopImage;
        player.stop ();
        player.setFramePosition(0);
        }

}